// TODO: Add file header here




// TODO: Add class header here
public class DS_My implements DataStructureADT< String, String > {

    // TODO may wish to define an inner class 
    // for storing key and value as a pair
    // such a class and its members should be "private"

    // Private Fields of the class
    // TODO create field(s) here to store data pairs
    
    public DS_My() {
        // TODO Auto-generated method stub
        
    }

    // TODO: add unimplemented methods
    // ProTip: Eclipse can do this for you

                                                          

}                            
    
